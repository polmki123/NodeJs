# nodejs로 쇼핑몰 구축하는 프로젝트 

[Develop Stack]

분야 | stack
------------ | -------------
서버 | Ubuntu ( AWS )
배포 | Docker
웹서버 | NGINX
API 서버 | Node.js
DB | MongoDB
